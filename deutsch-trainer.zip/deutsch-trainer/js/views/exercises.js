// Вправи до уроку: вибір варіанта, пропуск, порядок слів, переклад
import { getState, save, dayStats, markActive } from '../storage.js';
import { speak, stopSpeaking } from '../speech.js';
import { normalize, similarity } from '../match.js';
import { esc, icon, sayBtn, shuffle, umlautKeys } from '../ui.js';

const ARTICLE_DRILL = 4; // скільки питань «der, das чи die?» додати на початок

// Розминка з артиклями зі слів уроку
function articleDrill(lesson) {
  const nouns = lesson.words.filter((w) => w.pos === 'n' && w.art && !w.plOnly);
  return shuffle(nouns).slice(0, ARTICLE_DRILL).map((w) => ({
    type: 'choice',
    drill: true,
    q: `___ ${w.de}`,
    options: ['der', 'das', 'die'],
    answer: w.art,
    say: `${w.art} ${w.de}`,
    explain: `${w.art} ${w.de} — ${w.ua}.`,
  }));
}

// Повне правильне речення — показуємо й озвучуємо після відповіді
function fullText(ex) {
  if (ex.say) return ex.say;
  if (ex.type === 'choice' || ex.type === 'gap') {
    const answer = ex.type === 'choice' ? ex.answer : ex.answers[0];
    return ex.q.includes('___') ? ex.q.replace('___', answer) : answer;
  }
  return ex.answers[0];
}

const isRight = (value, answers) => answers.some((a) => normalize(a) === normalize(value));

export function render(app, content, lessonId) {
  const lesson = content.lessonById.get(lessonId);
  if (!lesson || lesson.planned || !lesson.exercises.length) {
    app.innerHTML = '<section class="done"><h1>Вправ поки немає</h1><a class="btn" href="#/lessons">До уроків</a></section>';
    return null;
  }
  const back = `#/lesson/${lesson.id}`;
  let items = [];
  let i = 0;
  let right = 0;
  let answered = false;

  function start() {
    items = [...articleDrill(lesson), ...lesson.exercises];
    i = 0;
    right = 0;
    show();
  }

  function frame(inner) {
    app.innerHTML = `
      <div class="session-top">
        <a class="back" href="${back}">${icon('back')}${esc(lesson.title)}</a>
        <span class="count">${i + 1} з ${items.length}</span>
      </div>
      <div class="progress-line" aria-hidden="true"><i style="--p:${(i / items.length).toFixed(3)}"></i></div>
      <article class="ex">${inner}<div class="fb-slot"></div></article>`;
  }

  function show() {
    answered = false;
    const ex = items[i];
    if (ex.type === 'choice') showChoice(ex);
    else if (ex.type === 'gap') showGap(ex);
    else if (ex.type === 'order') showOrder(ex);
    else showTranslate(ex);
  }

  function showChoice(ex) {
    const options = ex.drill ? ex.options : shuffle(ex.options);
    const q = esc(ex.q).replace('___', '<span class="blank"></span>');
    frame(`
      <p class="ex-task">${ex.drill ? 'Який артикль?' : 'Обери правильний варіант'}</p>
      <p class="ex-q" lang="de">${q}</p>
      <div class="options${ex.drill ? ' options-row' : ''}">
        ${options.map((o) => `<button class="option${ex.drill ? ` g-${o}` : ''}" data-opt="${esc(o)}" lang="de">${esc(o)}</button>`).join('')}
      </div>`);
    app.querySelectorAll('.option').forEach((btn) => btn.addEventListener('click', () => {
      if (answered) return;
      const ok = btn.dataset.opt === ex.answer;
      app.querySelectorAll('.option').forEach((b) => {
        b.disabled = true;
        if (b.dataset.opt === ex.answer) b.classList.add('is-right');
      });
      if (!ok) btn.classList.add('is-wrong');
      feedback(ex, ok);
    }));
  }

  function showGap(ex) {
    const [before, after = ''] = esc(ex.q).split('___');
    const width = Math.max(4, ex.answers[0].length + 2);
    frame(`
      <p class="ex-task">Встав пропущене слово${ex.hint ? ` <span class="ex-hint">(${esc(ex.hint)})</span>` : ''}</p>
      <form class="ex-form" autocomplete="off">
        <p class="ex-q" lang="de">${before}<input id="ex-input" class="gap-input" style="width:${width}ch" type="text" autocapitalize="off" autocorrect="off" spellcheck="false" lang="de" aria-label="Пропущене слово">${after}</p>
        ${umlautKeys('ex-input')}
        <button class="btn btn-marker" type="submit">Перевірити</button>
      </form>`);
    bindTyped(ex, (value) => ({ ok: isRight(value, ex.answers) }));
  }

  function showTranslate(ex) {
    frame(`
      <p class="ex-task">Переклади німецькою</p>
      <p class="ex-prompt">${esc(ex.ua)}</p>
      <form class="ex-form" autocomplete="off">
        <input id="ex-input" class="text-input" type="text" autocapitalize="sentences" autocorrect="off" spellcheck="false" lang="de" aria-label="Переклад німецькою">
        ${umlautKeys('ex-input')}
        <button class="btn btn-marker" type="submit">Перевірити</button>
      </form>`);
    bindTyped(ex, (value) => {
      const ok = isRight(value, ex.answers);
      const best = Math.max(...ex.answers.map((a) => similarity(normalize(a), normalize(value))));
      return { ok, close: !ok && best >= 0.85 };
    });
  }

  // Спільне для полів введення: Enter перевіряє, а після відповіді — йде далі
  function bindTyped(ex, check) {
    const input = app.querySelector('#ex-input');
    input.focus();
    app.querySelector('.ex-form').addEventListener('submit', (e) => {
      e.preventDefault();
      if (answered) {
        next();
        return;
      }
      const value = input.value.trim();
      if (!value) {
        input.focus();
        return;
      }
      const result = check(value);
      input.readOnly = true;
      input.classList.add(result.ok ? 'is-right' : 'is-wrong');
      feedback(ex, result.ok, result.close);
    });
  }

  function showOrder(ex) {
    let pool = shuffle(ex.words);
    // Щоб картки не лягли одразу в правильному порядку
    if (normalize(pool.join(' ')) === normalize(ex.answers[0])) pool = [...pool].reverse();
    frame(`
      <p class="ex-task">Склади речення</p>
      <p class="ex-prompt">${esc(ex.ua)}</p>
      <div class="answer-line" aria-label="Твоє речення" lang="de"></div>
      <div class="chips pool" lang="de">${pool.map((w) => `<button class="chip" type="button">${esc(w)}</button>`).join('')}</div>
      <div class="row-actions">
        <button class="btn btn-marker" data-act="check">Перевірити</button>
        <button class="btn btn-ghost" data-act="reset">Почати спочатку</button>
      </div>`);
    const line = app.querySelector('.answer-line');
    const poolEl = app.querySelector('.pool');
    app.querySelector('.ex').addEventListener('click', (e) => {
      const chip = e.target.closest('.chip');
      if (!chip || answered) return;
      (chip.parentElement === poolEl ? line : poolEl).appendChild(chip);
    });
    app.querySelector('[data-act="reset"]').addEventListener('click', () => {
      if (answered) return;
      line.querySelectorAll('.chip').forEach((c) => poolEl.appendChild(c));
    });
    app.querySelector('[data-act="check"]').addEventListener('click', () => {
      if (answered) return;
      const built = [...line.querySelectorAll('.chip')].map((c) => c.textContent).join(' ');
      if (!built) return;
      feedback(ex, isRight(built, ex.answers));
    });
  }

  function feedback(ex, ok, close = false) {
    answered = true;
    if (ok) right++;
    const full = fullText(ex);
    app.querySelectorAll('[data-act="check"], [data-act="reset"], .ex-form [type="submit"], .umlauts').forEach((el) => { el.hidden = true; });
    const title = ok ? 'Правильно!' : close ? 'Майже! Перевір написання.' : 'Неправильно.';
    app.querySelector('.fb-slot').innerHTML = `
      <div class="fb ${ok ? 'ok' : 'bad'}" role="status">
        <p class="fb-title">${title}</p>
        <p class="fb-answer"><b lang="de">${esc(full)}</b>${sayBtn(full)}</p>
        ${ex.explain ? `<p class="fb-explain">${esc(ex.explain)}</p>` : ''}
        <button class="btn btn-marker" data-act="next">${i + 1 < items.length ? 'Далі' : 'Показати результат'}</button>
      </div>`;
    const nextBtn = app.querySelector('[data-act="next"]');
    nextBtn.addEventListener('click', next);
    nextBtn.focus({ preventScroll: true });
    nextBtn.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    if (getState().settings.autoplay) speak(full);
  }

  function next() {
    stopSpeaking();
    i++;
    if (i < items.length) show();
    else finish();
  }

  function finish() {
    const state = getState();
    const pct = Math.round((right / items.length) * 100);
    const prevBest = state.exercises[lesson.id] || 0;
    state.exercises[lesson.id] = Math.max(prevBest, pct);
    dayStats().exercises++;
    markActive();
    save();
    const title = pct >= 90 ? 'Чудово!' : pct >= 70 ? 'Добре!' : 'Варто повторити';
    const record = prevBest && pct > prevBest ? ` Це новий найкращий результат (був ${prevBest}%).` : '';
    app.innerHTML = `
      <section class="done">
        <p class="result-score"><span class="num">${right}</span> з ${items.length}</p>
        <h1>${title}</h1>
        <p>Результат: ${pct}%.${record}${pct < 70 ? ' Перечитай граматику уроку й спробуй ще раз.' : ''}</p>
        <div class="row-actions">
          <button class="btn btn-marker" data-act="again">Ще раз</button>
          <a class="btn" href="${back}">До уроку</a>
        </div>
      </section>`;
    app.querySelector('[data-act="again"]').addEventListener('click', start);
  }

  start();
  return () => stopSpeaking();
}
