// Список уроків і сторінка уроку: граматика й слова
import { getState } from '../storage.js';
import { label, pluralLabel, lessonStats } from '../content.js';
import { isLearned } from '../srs.js';
import { esc, fmt, wordHTML, sayBtn, icon } from '../ui.js';

export function renderList(app, content) {
  const state = getState();
  app.innerHTML = content.levels
    .filter((level) => level.lessons.length)
    .map((level) => `
      <header class="page-head">
        <h1>Уроки ${esc(level.id)}</h1>
        <p class="muted">Теми й граматика йдуть приблизно в тому ж порядку, що й у підручнику Menschen ${esc(level.id)}.</p>
      </header>
      <ol class="lesson-list">${level.lessons.map((l) => lessonRow(l, state)).join('')}</ol>`)
    .join('');
}

function lessonRow(l, state) {
  const head = `<span class="num">${l.num}</span><span class="body"><span class="t">${esc(l.title)}</span><span class="de" lang="de">${esc(l.titleDe)}</span>`;
  if (l.planned) {
    return `<li class="is-planned"><a class="lesson-row" href="#/lesson/${l.id}">${head}</span><span class="meta">скоро</span></a></li>`;
  }
  const s = lessonStats(l, state);
  return `<li><a class="lesson-row" href="#/lesson/${l.id}">${head}<span class="bar"><i style="--p:${s.progress.toFixed(3)}"></i></span></span><span class="meta">${s.learned}/${s.total}</span></a></li>`;
}

export function renderLesson(app, content, id) {
  const lesson = content.lessonById.get(id);
  if (!lesson) {
    app.innerHTML = '<section class="done"><h1>Такого уроку немає</h1><a class="btn" href="#/lessons">До списку уроків</a></section>';
    return;
  }
  const state = getState();
  const head = `
    <a class="back" href="#/lessons">${icon('back')}Уроки</a>
    <header class="lesson-head">
      <span class="lesson-num">${lesson.num}</span>
      <div><h1>${esc(lesson.title)}</h1><p class="de-title" lang="de">${esc(lesson.titleDe)}</p></div>
    </header>
    <p class="topic">${esc(lesson.topic)}</p>`;

  if (lesson.planned) {
    app.innerHTML = `${head}
      <section class="block">
        <h2>Що буде в уроці</h2>
        <ul class="plan">${(lesson.grammarPlan || []).map((g) => `<li>${esc(g)}</li>`).join('')}</ul>
        <p class="muted">Урок ще не наповнений. Попроси Claude Code: «Наповни урок ${lesson.num} за правилами з CLAUDE.md».</p>
      </section>`;
    return;
  }

  const s = lessonStats(lesson, state);
  app.innerHTML = `${head}
    <div class="row-actions">
      <a class="btn btn-marker" href="#/cards/${lesson.id}">Вчити слова</a>
      <a class="btn" href="#/exercises/${lesson.id}">Вправи${s.ex ? ` (${s.ex}%)` : ''}</a>
    </div>
    <p class="muted">Вивчено ${s.learned} з ${s.total} слів.</p>

    <section class="block">
      <h2>Граматика</h2>
      ${lesson.grammar.map(gramHTML).join('')}
    </section>

    <section class="block">
      <h2>Слова</h2>
      <p class="legend"><span><b class="g-der">der</b> чоловічий</span><span><b class="g-das">das</b> середній</span><span><b class="g-die">die</b> жіночий</span></p>
      <ul class="word-list">${lesson.words.map((w) => wordRow(w, state)).join('')}</ul>
    </section>`;
}

function gramHTML(g) {
  let table = '';
  if (g.table) {
    const hasHead = g.table[0][0] === '';
    const rows = g.table
      .map((row, i) => `<tr>${row.map((cell) => (hasHead && i === 0 ? `<th>${fmt(cell)}</th>` : `<td>${fmt(cell)}</td>`)).join('')}</tr>`)
      .join('');
    table = `<div class="table-wrap"><table lang="de">${rows}</table></div>`;
  }
  return `<article class="gram"><h3>${esc(g.title)}</h3>${g.text ? `<p>${fmt(g.text)}</p>` : ''}${table}</article>`;
}

function wordRow(w, state) {
  const pl = pluralLabel(w);
  const extra = [w.forms, w.note].filter(Boolean).map(esc).join('<br>');
  const learned = isLearned(state.cards[w.id]);
  return `
    <li${learned ? ' class="is-learned"' : ''}>
      <div class="wl-de">${wordHTML(w)}${pl ? `<span class="wl-pl">${esc(pl)}</span>` : ''}${learned ? '<span class="wl-ok" title="Вивчено">✓</span>' : ''}</div>
      <div class="wl-ua">${esc(w.ua)}</div>
      ${extra ? `<div class="wl-extra" lang="de">${extra}</div>` : ''}
      ${sayBtn(label(w))}
    </li>`;
}
